package it.polimi.template.model;

import java.util.Observable;
import java.util.Random;

public class Drone {

	public static final int LONG = 1;
	public static final int SHORT = 2;
	public static final int HEAVY = 3;
	public static final int LIGHT = 4;

	public static final int FREE = 5;
	public static final int BUSY = 6;
	public static final int CHARGING = 7;

	private int id;
	private int status;
	private int shapeCategory;
	private int batteryLevel;

	public Drone() {
		this.id = new Random().nextInt(Integer.MAX_VALUE) + 1;
		this.status = 5;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getShapeCategory() {
		return shapeCategory;
	}

	public void setShapeCategory(int shapeCategory) {
		this.shapeCategory = shapeCategory;
	}

	public int getBatteryLevel() {
		return batteryLevel;
	}

	public void setBatteryLevel(int batteryLevel) {
		this.batteryLevel = batteryLevel;
	}

	public boolean flyToAndDoAction(String target, final Action action) {
		if (this.flyTo(target)) {
			if (action.doAction()) {
				return true;
			}
		}
		// TODO settare la posizione corrente come source location per il
		// ripristino del trip
		return false;
	}

	private boolean flyTo(String target) {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return true;
	}

	public static String getStatusNameFromValue(int value) {

		switch (value) {
		case FREE:
			return "FREE";
		case BUSY:
			return "BUSY";
		case CHARGING:
			return "CHARGING";
		default:
			return "Unknown";
		}
	}
}
