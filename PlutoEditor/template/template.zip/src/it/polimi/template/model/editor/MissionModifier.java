package it.polimi.template.model.editor;

import it.polimi.template.model.*;

public class MissionModifier implements Node {

	@Override
	public Mission run(Mission m) {
		// TODO Auto-generated method stub
		return null;
	}

}
