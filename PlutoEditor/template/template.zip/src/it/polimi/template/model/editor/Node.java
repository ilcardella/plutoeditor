package it.polimi.template.model.editor;

import it.polimi.template.model.*;

public interface Node {
	
	public Mission run(Mission m);

}
