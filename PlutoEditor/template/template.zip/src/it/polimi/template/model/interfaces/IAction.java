package it.polimi.template.model.interfaces;

public interface IAction {

	public void doAction();
	
	public boolean isItemRequired();
}
