package it.polimi.template.model.interfaces;

public interface IAction {

	public boolean doAction();
	
	public boolean isItemRequired();
}
