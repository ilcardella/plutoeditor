package it.polimi.template.model.interfaces;

public interface IAction {

	public Object doAction();
	
	public boolean isItemRequired();
}
